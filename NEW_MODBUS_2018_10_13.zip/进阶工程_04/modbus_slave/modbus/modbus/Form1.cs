﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

//Serial 
using System.IO.Ports;

//textbox 正则表达式
using System.Text.RegularExpressions;

//socket
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Net.NetworkInformation;

namespace modbus
{
    public partial class Form1 : Form
    {
        //全局变量

        //方法封装
        Action<TextBox, string> Show_TextBox_Message;

        //RTU、ASCII方式选择
        byte RTU_ENABLE = 0;
        byte ASCII_ENABLE = 0;

        //UART、TCP/IP方式选择
        byte UART_ENABLE = 0;
        byte TCP_ENABLE = 0;

        //MBAP(TCP/IP)MODBUS发送使能(加入serial modbus 发送函数)
        byte MBAP_TCP_ENABLE = 0;

        //自动搜索串口最大数目
        byte SREARCH_SERIAL_CONN_PORT = 15;

        //发送、接收次数计数
        int TX_CNT = 0;
        int RX_CNT = 0;

        //TCP设置相关#############################################################################################

        //客户端socket
        Socket client_socket = null;

        //保存已经保存的客户端线程
        private List<Thread> client_conn_thread_list;

        //创建一个定时器
        //定时接收socket服务器传来的信息
        System.Timers.Timer Tcp_Socket_Rec_Timer = new System.Timers.Timer();

        //TCP连接成功标志
        byte TCP_CONN_SUCCESS_FLAG = 0;

        //连接按键状态改变标志
        byte TCP_LINK_STATE_CNT = 0;

        //TCP连接失败次数统计标志
        byte TCP_CONN_FAILED_CNT = 0;

        //TCP接收成功标记
        byte TCP_REC_SUCCESS_FLAG = 0;

        //标志位设置相关##########################################################################################

        //自动搜索串口数目完成标志 1 ok 
        //其它值 error
        byte search_serial_conn_port_flag = 0;

        //打开串口标志 1 ok 
        //关闭串口标志 2 ok 
        //其它值 error
        byte open_serial_conn_port_flag = 0;

        //清除显示内容标志
        byte clear_tx_flag = 0;
        byte clear_rx_flag = 0;

        //serial 数据接收完毕标识 1 -> 接收完毕
        byte serialport_rec_data_OK = 0;

        //委托调用 serial接收使用
        delegate void Serial_Rec_Data_Deal();
        Serial_Rec_Data_Deal Dele_Serial_Rec_Deal;

        //帧命令解析
        Rec_Frame_List Frame_List = new Rec_Frame_List(128);

        //循环队列实例
        loop_queue_list<byte> queue = new loop_queue_list<byte>(128);

        //CRC计算实例
        cal_check_list cal_crc = new cal_check_list();

        //正则表达式
        match_textbox_list match_data = new match_textbox_list(); 

        public Form1()
        {
            InitializeComponent();          
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Init_View();
        }

        //初始化
        public void Init_View()
        {
            //modbus
            textBox2.Text = "1";        //设备地址
            textBox16.Text = "30";      //定时时间 *100ms

            //串口
            textBox1.Text = "Close!!!"; //串口状态

            //TCP/IP
            textBox4.Text = " ";      //socket端口
            textBox5.Text = "Close!!! ";//socket状态

            //显示
            textBox8.Text = " ";
            textBox9.Text = " ";

            //回应时间 
            textBox21.Text = "1";       // *100ms

            //发送次数等信息
            textBox3.Text = " ";
            textBox19.Text = " ";
            textBox20.Text = " ";
            textBox22.Text = " ";

            //清零按键
            button8.Text = "已清零";
            button9.Text = "已清零";

            //默认TCP/IP不可使用
            comboBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            button3.Enabled = false;

            //默认RTU方式
            RTU_ENABLE = 1;
            ASCII_ENABLE = 0;
            MBAP_TCP_ENABLE = 0;

            //默认UART方式
            UART_ENABLE = 1;
            TCP_ENABLE = 0;

            //自动扫描 打开串口 按键状态
            button1.BackColor = Color.Green;
            button2.BackColor = Color.Green;

            //委托方法相关操作********************************************************************************************

            //在子线程中更新界面元素
            Show_TextBox_Message = delegate(TextBox show_textbox, string str_in)
            {
                Show_String(show_textbox, str_in);
            };

            //tcp相关操作********************************************************************************************

           

            //serial相关操作********************************************************************************************

            //关闭跨线程检测
            //否则串口无法接收数据
            System.Windows.Forms.Control.CheckForIllegalCrossThreadCalls = false;

            //委托实例化
            //否则无法使用委托 串口接收使用
            Dele_Serial_Rec_Deal = new Serial_Rec_Data_Deal(MyDele_Serial_Rec_Deal);

            //串口接收事件需自己手动注册
            serialPort1.DataReceived += new SerialDataReceivedEventHandler(Serial_Rec_Data);
        }

        /*##############################################################################################################界面程序开始*/

        //通信底层选择 serial
        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            //如果突然切换到serial通信 
            //必须关闭TCP
            //恢复没有扫描状态

            //TCP断开连接
            //暂未实现#######################################################################################################???

            radioButton1.Enabled = true;//ASCII恢复

            button3.Text = "连接";
            button3.BackColor = Color.Green;

            comboBox3.Text = " ";
            textBox4.Text = " ";
            textBox5.Text = "Close!!!";

            //TCP/IP不可使用
            comboBox3.Enabled = false;
            textBox4.Enabled = false;
            textBox5.Enabled = false;
            button3.Enabled = false;
            MBAP_TCP_ENABLE = 0;

            //serial可使用
            comboBox1.Enabled = true;
            comboBox2.Enabled = true;
            textBox1.Enabled = true;
            button1.Enabled = true;
            button2.Enabled = true;

            //UART、TCP/IP方式选择
            UART_ENABLE = 1;
            TCP_ENABLE = 0;
        }

        //通信底层选择 tcp
        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            //如果突然切换到TCP通信 
            //必须关闭serial 
            //恢复没有扫描状态

            radioButton1.Checked = false;
            radioButton1.Enabled = false;//ASCII禁止
            Close_Serial_Conn_Port(serialPort1);

            button1.Text = "扫描端口";
            button1.BackColor = Color.Green;

            button2.Text = "打开串口";
            button2.BackColor = Color.Green;

            comboBox1.Text = " ";
            comboBox2.Text = " ";
            textBox1.Text = "Close!!! ";

            //serial不可使用
            comboBox1.Enabled = false;
            comboBox2.Enabled = false;
            textBox1.Enabled = false;
            button1.Enabled = false;
            button2.Enabled = false;

            //TCP/IP可使用
            comboBox3.Enabled = true;
            textBox4.Enabled = true;
            textBox5.Enabled = true;
            button3.Enabled = true;
            MBAP_TCP_ENABLE = 1;

            //UART、TCP/IP方式选择
            UART_ENABLE = 0;
            TCP_ENABLE = 1;

            //清空上次数据
            comboBox3.Items.Clear();

            //获取本机IP地址
            string[] get_ipaddr = get_local_addr();

            for (int i = 0; i < get_ipaddr.Length; i++)
            {
                comboBox3.Items.Add(get_ipaddr[i]);
            }

            comboBox3.SelectedIndex = 0;
            textBox4.Text = "502";

            client_conn_thread_list = new List<Thread>();

            //关闭定时器
            Tcp_Socket_Rec_Timer.Enabled = false;

            //创建TCP接收线程
            Thread Tcp_Socket_Rec_Timer_thread = new Thread(Tcp_Socket_Rec_TimerMange);

            client_conn_thread_list.Add(Tcp_Socket_Rec_Timer_thread);//线程保存

            Tcp_Socket_Rec_Timer_thread.Start();
        }

        //通信方式选择 RTU
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            //RTU方式
            RTU_ENABLE = 1;
            ASCII_ENABLE = 0;
        }

        //通信方式选择 ASCII
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            //ASCII方式
            RTU_ENABLE = 0;
            ASCII_ENABLE = 1;
        }

        //扫描端口serial
        private void button1_Click(object sender, EventArgs e)
        {
            //UART方式选择
            //TCP失效
            if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))
            {
                Search_Serial_Conn_Port(serialPort1, comboBox1, SREARCH_SERIAL_CONN_PORT);

                if (search_serial_conn_port_flag == 1)
                {
                    search_serial_conn_port_flag = 0;

                    button1.Text = "已扫描";
                    button1.BackColor = Color.Red;
                }
                else//error com<2 已经写死 不用考虑
                {
                    search_serial_conn_port_flag = 0;
                }
            }
        }

        //打开串口
        private void button2_Click(object sender, EventArgs e)
        {
            string datestring = " ";

            //UART方式选择
            //TCP失效
            if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))
            {
                try//解决 因为缺少参数 导致卡死的现象bug 21:06 2018/10/15
                {
                    if ((comboBox1.SelectedItem.ToString() != " ") && (comboBox2.SelectedItem.ToString() != " "))//填写Com Boud
                    {
                        Create_Serial_Conn_Port(serialPort1, comboBox1, comboBox2);

                        if (open_serial_conn_port_flag == 1)//open
                        {
                            open_serial_conn_port_flag = 0;

                            button2.Text = "关闭串口";
                            button2.BackColor = Color.Red;

                            //TCP选项禁止 serial运行
                            radioButton4.Enabled = false;
                            radioButton3.Enabled = true;

                            //提示信息显示
                            textBox1.Invoke(Show_TextBox_Message, textBox1, serialPort1.PortName + "," + serialPort1.BaudRate.ToString() + "," + "N" + "," + serialPort1.DataBits.ToString() + "," + serialPort1.StopBits.ToString());

                            comboBox1.Text = "";//清除上次遗留的数据
                            comboBox2.Text = "";

                            //COM BOUD 扫描按键 状态 均失效
                            comboBox1.Enabled = false;
                            comboBox2.Enabled = false;
                            button1.Enabled = false;
                            textBox1.Enabled = false;

                            //自动扫描按键 不可操作状态
                            button1.Text = "不可操作";
                            button1.BackColor = Color.Goldenrod;

                            //获取时间
                            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                            //显示
                            textBox20.Invoke(Show_TextBox_Message, textBox20, datestring);
                            textBox19.Invoke(Show_TextBox_Message, textBox19, " ");

                            //状态栏改变
                            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus可以通信");

                        }
                        else if (open_serial_conn_port_flag == 2)//close
                        {
                            open_serial_conn_port_flag = 0;

                            button2.Text = "打开串口";
                            button2.BackColor = Color.Green;

                            //serial、TCP运行
                            radioButton3.Enabled = true;
                            radioButton4.Enabled = true;

                            //提示信息显示
                            textBox1.Invoke(Show_TextBox_Message, textBox1, "Close!!!");

                            //COM BOUD 扫描按键 状态 恢复
                            comboBox1.Enabled = true;
                            comboBox2.Enabled = true;
                            button1.Enabled = true;
                            textBox1.Enabled = true;

                            //自动扫描按键 恢复状态
                            button1.Text = "可扫描";
                            button1.BackColor = Color.Green;

                            //获取时间
                            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                            //显示
                            textBox19.Invoke(Show_TextBox_Message, textBox19, datestring);

                            //状态栏改变
                            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!");
                        }
                        else
                        { }
                    }
                }
                catch
                {
                    MessageBox.Show("打开串口失败！请检查端口号和波特率", "打开串口失败提示");
                }
            }
        }

        //连接tcp socket
        private void button3_Click(object sender, EventArgs e)          
        {
            string datestring = " ";

            if ((UART_ENABLE == 0) && (TCP_ENABLE == 1))
            { 
                TCP_LINK_STATE_CNT++;
                if (TCP_LINK_STATE_CNT % 2 != 0)//第一次
                {
                    Create_Tcp_Socket(comboBox3, textBox4);

                    if (TCP_CONN_SUCCESS_FLAG == 1)//成功连接
                    {
                        TCP_CONN_SUCCESS_FLAG = 0;

                        button3.Text = "断开连接";//连接按键状态改变
                        button3.BackColor = Color.Red;

                        comboBox3.Enabled = false;//状态禁止改变
                        textBox4.Enabled = false;

                        datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//开始时间
                        textBox20.Invoke(Show_TextBox_Message, textBox20, datestring);
                    }
                    else//失败
                    {
                        TCP_CONN_SUCCESS_FLAG = 0;
                        TCP_LINK_STATE_CNT = 0;
                        TCP_CONN_FAILED_CNT++;

                        comboBox3.Enabled = true;//状态允许改变
                        textBox4.Enabled = true;

                        textBox5.Invoke(Show_TextBox_Message, textBox5, " ");
                    
                    }
                
                }
                else//断开连接
                { 
              
                    Close_Tcp_Socket();
                    TCP_LINK_STATE_CNT = 0;

                    button3.Text = "连接";
                    button3.BackColor = Color.Green;

                    comboBox3.Enabled = true;//状态允许改变
                    textBox4.Enabled = true;

                    textBox5.Invoke(Show_TextBox_Message, textBox5, "主动与服务器断开连接!");

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");
                    textBox19.Invoke(Show_TextBox_Message, textBox19, datestring);

                }
                if (TCP_CONN_FAILED_CNT == 3)//连接失败超3次 弹出错误提示
                {
                    TCP_CONN_FAILED_CNT = 0;
                    MessageBox.Show("连接服务器失败次数超限，请检查客户端及服务器的IP地址、端口号", "连接错误提示");
                }
            }
        }

        // 清除接收内容
        private void button8_Click(object sender, EventArgs e)
        {
            byte show_flag = 0;//修复 软件为打开显示Modbus可以通信的bug 21:27 2018/10/15 

            clear_rx_flag++;
            if (clear_rx_flag % 2 != 0)
            {
                if (textBox9.Text != " ")//存在数据
                {
                    RX_CNT = 0;
                    textBox9.Text = " ";
                    textBox22.Text = " ";

                    //信息提示
                    button8.Text = "已清零";
                    show_flag = 1;
                }
                else//没有任何数据
                {
                }
            }
            else//第一次按下
            {
                if (textBox9.Text == " ")//不存在数据
                {
                    //信息提示
                    button8.Text = "已清零";
                    show_flag = 1;
                }
                else
                {
                }
                clear_rx_flag = 0;
            }
            if (show_flag == 1)
            {
                if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))
                {
                    if (serialPort1.IsOpen)
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus可以通信");
                    }
                    else
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!");
                    }

                }
                else if ((UART_ENABLE == 0) && (TCP_ENABLE == 1))
                {
                    if (client_socket.Connected)
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus可以通信");
                    }
                    else
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!");
                    }
                }
                else
                {

                }

                show_flag = 0;
            }   
        }

        // 清除发送内容
        private void button9_Click(object sender, EventArgs e)
        {
            byte show_flag = 0;//修复 软件为打开显示Modbus可以通信的bug 21:27 2018/10/15 

            clear_tx_flag++;
            if (clear_tx_flag % 2 != 0)
            {
                if (textBox8.Text != " ")//存在数据
                {
                    TX_CNT = 0;
                    textBox8.Text = " ";
                    textBox3.Text = " ";

                    //信息提示
                    button9.Text = "已清零";
                    show_flag = 1;
                }
                else//没有任何数据
                {
                }
            }
            else//第一次按下
            {
                if (textBox8.Text == " ")//不存在数据
                {
                    //信息提示
                    button9.Text = "已清零";
                    show_flag = 1;
                }
                else
                {
                }
                clear_tx_flag = 0;
            }

            if (show_flag == 1)
            {
                if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))
                {
                    if (serialPort1.IsOpen)
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus可以通信");
                    }
                    else
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!");
                    }

                }
                else if ((UART_ENABLE == 0) && (TCP_ENABLE == 1))
                {
                    if (client_socket.Connected)
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus可以通信");
                    }
                    else
                    {
                        textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus基本配置 -> 通信载体、通信方式未选择，不能通信!");
                    }
                }
                else
                {

                }

                show_flag = 0;
            }   
            
        }

        //关于软件
        private void button6_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Modbus_Client V1.7 软件会持续更新!\n 实现MODBUS-TCP、MODBUS_RTU、MODBUS_ASCII \n MODBUS 功能码03、06 \n 作者:廖玥英 \n 联系方式(QQ):1092003911 \n 完成日期:2018/10/12", "关于Modbus_Client软件");
        }

        //更多功能码相关操作
        private void button7_Click(object sender, EventArgs e)
        {
            MessageBox.Show("暂未开放!!!敬请期待!!!", "关于更多功能码说明");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
           
        }

        /*##############################################################################################################界面程序结束*/

        /*################################################################################################################程序开始*/

        //串口接收事件
        private void Serial_Rec_Data(object sender, SerialDataReceivedEventArgs e)
        {
            MySerial_Rec_Event(serialPort1);
        }

        //委托事件
        public void MyDele_Serial_Rec_Deal()
        {
            if (serialport_rec_data_OK == 0)//数据没有接收完毕
            {
                return;
            }

            if ((RTU_ENABLE == 1) && (ASCII_ENABLE == 0))
            {
                Serial_Deal_Rec_RTU();
            }
            else if ((RTU_ENABLE == 0) && (ASCII_ENABLE == 1))
            {
                Serial_Deal_RecFrame_ASCII();
            }
            else
            { 
            
            }

            serialport_rec_data_OK = 0;
        }

        /*################################################################################################################TCP程序开始*/

        private string[] get_local_addr()
        {
            string host_mame = " ";

            //获取主机名
            host_mame = Dns.GetHostName();

            //获取主机地址信息
            IPHostEntry ipHostEntry = Dns.GetHostEntry(host_mame);

            string[] get_ipaddr = new string[ipHostEntry.AddressList.Length];
            int i = 0;

            foreach (IPAddress ip_addr in ipHostEntry.AddressList)
            {
                get_ipaddr[i] = ip_addr.ToString();
                i++;
            }
            return get_ipaddr;
        }

        //关闭TCP连接
        public void Close_Tcp_Socket()
        {
            Tcp_Socket_Rec_Timer.Enabled = false;

            client_socket.Close();

            //关闭线程
            for (int i = 0; i < client_conn_thread_list.Count; i++)
            {
                client_conn_thread_list[i].Abort();
            }
        }

        //创建TCP
        public void Create_Tcp_Socket(ComboBox ip_combox, TextBox port_textbox)
        {
            string str_ip_addr = " ";
            int port_name = 0;

            if ((ip_combox.SelectedItem.ToString() != " ") && (port_textbox.Text != " "))//填写IP地址 端口号
            {
                str_ip_addr = ip_combox.SelectedItem.ToString();
                port_name = Convert.ToInt32(port_textbox.Text);//数据类型一定是 int 否则会出错

                client_socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
                IPAddress ip = IPAddress.Parse(str_ip_addr);
                IPEndPoint point = new IPEndPoint(ip, port_name);

                //尝试连接
                try
                {
                    client_socket.Connect(point);

                    textBox5.Invoke(Show_TextBox_Message, textBox5, "客户端连接中。。。");
                }
                catch
                {
                    //关闭socket
                    Close_Tcp_Socket();
                }

                //判断是否已经连接上
                try
                {
                    if (client_socket.Connected == true)
                    {
                        textBox5.Invoke(Show_TextBox_Message, textBox5, "与服务器连接成功!!!");
                        Tcp_Socket_Rec_Timer.Enabled = true;
                        TCP_CONN_SUCCESS_FLAG = 1;
                    }
                    else
                    {
                        textBox5.Invoke(Show_TextBox_Message, textBox5, "与服务器连接失败!!!");
                        Tcp_Socket_Rec_Timer.Enabled = false;
                        TCP_CONN_SUCCESS_FLAG = 2;
                    }
                }
                catch
                {
                    textBox5.Invoke(Show_TextBox_Message, textBox5, "检测连接状态出错!");
                    TCP_CONN_SUCCESS_FLAG = 2;
                }
            }
            else
            {
                MessageBox.Show("请填写正确的IP地址以及端口号!!!", "连接错误提示");
            }
        }

        //定时器事件
        void Tcp_Socket_Rec_TimerMange()
        {
            Tcp_Socket_Rec_Timer.Elapsed += new ElapsedEventHandler(Tcp_Recive_Deal);//定时事件的方法    
            Tcp_Socket_Rec_Timer.Interval = 100;
        }

        //tcp接收程序 线程
        void Tcp_Recive_Deal(object sender, EventArgs e)
        {
            int temp_len = 0;
            string datestring = " ";

            byte[] get_data = new byte[256];
            string[] temp_str = new string[256];

            while (true)
            {
                try
                {
                    if (client_socket.Connected)
                    {
                        temp_len = client_socket.Receive(get_data);

                        if (temp_len == 0)//无数据
                        {
                            break;
                        }
                        else
                        {
                            Socket_Deal_Rec_RTU(temp_len, get_data);
                        }
                    }
                    else
                    {
                        Close_Tcp_Socket();
                        break;
                    }
                }
                catch
                {
                    //关闭socket
                    Close_Tcp_Socket();
                    break;
                }
            }
        }

        ////TCP发送函数
        //public void Tcp_Send_Deal()
        //{
        //    try
        //    {
        //        if (client_socket.Connected)
        //        {
        //            //发送数据
        //            //tcp_socket.Send(Send_Buff, 0, num_of_page + num_of_singe, SocketFlags.None);                   
        //        }
        //        else
        //        {
        //            Close_Tcp_Socket();
        //        }
        //    }
        //    catch
        //    {
        //        Close_Tcp_Socket();
        //    }
        //}

        /*################################################################################################################TCP程序结束*/


        /*################################################################################################################程序结束*/

        //串口操作三部曲 接收事件 打开串口 搜索串口########################################################################程序开始

        //串口接收事件提前处理
        void MySerial_Rec_Event(SerialPort serialport_in)
        {
            int rec_temp_len = 0;
            byte[] rec_data = new byte[128];

            try
            {
                if (serialport_in.IsOpen)//可以通信
                {
                    rec_temp_len = serialPort1.BytesToRead;
                    if (rec_temp_len != 0)
                    {
                        serialport_in.Read(rec_data, 0, rec_temp_len);
                        queue.Insert_Queue(rec_data, rec_temp_len);       //数据入栈

                        serialport_rec_data_OK = 1;                       //接收事件完成标志

                        serialport_in.DiscardInBuffer();                  //将上次接收的数据丢弃方便下一次接收

                        this.Invoke(Dele_Serial_Rec_Deal, null);           //委托      
                    }
                    else
                    {
                        return;
                    }
                }
                else
                {
                    //关闭通信
                    serialport_in.Close();
                }
            }
            catch
            {
                //关闭通信
                serialport_in.Close();
            }
        }

        //关闭串口
        private void Close_Serial_Conn_Port(SerialPort MySerialport)
        {
            if (MySerialport.IsOpen)//关闭
            {
                try
                {
                    MySerialport.Close();
                }
                catch
                { }
            }
        }

        //打开串口
        private void Create_Serial_Conn_Port(SerialPort MySerialport, ComboBox MyCombox_ComX, ComboBox MyCombox_BoudX)
        {
            if (MySerialport.IsOpen)//关闭
            {
                try
                {
                    MySerialport.Close();
                    open_serial_conn_port_flag = 2;
                }
                catch
                { }
            }
            else
            {
                try
                {
                    //COM BOUD 必须元素
                    MySerialport.PortName = MyCombox_ComX.Text;
                    MySerialport.BaudRate = Convert.ToInt32(MyCombox_BoudX.Text, 10);
                    MySerialport.Open();
                    open_serial_conn_port_flag = 1;
                }
                catch
                { }
            }
        }

        //搜索端口号 serial
        private void Search_Serial_Conn_Port(SerialPort MySerialport, ComboBox MyComBox_ComX, int ComX_Num)
        {
            string str = " ";

            MyComBox_ComX.Items.Clear();//清除之前的内容

            if (ComX_Num >= 2)
            {
                for (int i = 1; i < ComX_Num; i++)//没有CMO0
                {
                    try
                    {
                        str = "COM" + i.ToString();
                        MySerialport.PortName = str;

                        MySerialport.Open();
                        MyComBox_ComX.Items.Add(str);//添加到下拉列表
                        MySerialport.Close();
                    }
                    catch
                    {
                    }
                }
                search_serial_conn_port_flag = 1;
            }
            else
            {
                search_serial_conn_port_flag = 2;
                MessageBox.Show("自动搜索COM口失败!请检查输入自动搜索COM数量设置 \n 建议自动搜索COM数量设置范围10->20为宜 \n 软件默认设置自动搜索COM数量为15 ", "自动搜索COM数量失败提示");
            }
        }

        //串口操作三部曲 接收事件 打开串口 搜索串口#########################################################################程序结束

        /*##############################################################################################################其它程序开始*/

        //获取当前时间
        public static string GetTimeStamp()
        {
            TimeSpan ts = DateTime.UtcNow - new DateTime(1970, 1, 1, 0, 0, 0, 0);
            return Convert.ToInt64(ts.TotalSeconds).ToString();
        }

        public static DateTime GetTime(string timeStamp)
        {
            DateTime dtStart = TimeZone.CurrentTimeZone.ToLocalTime(new DateTime(1970, 1, 1));

            long lTime = long.Parse(timeStamp + "0000000");
            TimeSpan toNow = new TimeSpan(lTime);
            return dtStart.Add(toNow);
        }

        //显示字符串
        public void Show_String(TextBox show_textbox, string str_in)
        {

            //if ("".Equals(show_textbox.Text))
            //{
            show_textbox.Text = str_in;
            //}
            //else
            //{
            //    show_textbox.Text += str_in;
            //}
         
        }

        //字节数组转换成字符串数组并显示
        public void Show_Byte_To_String(byte[] byte_in, string[] str_out, int len_in, TextBox show_textbox)
        {
            //清空上一次数据
            show_textbox.Text = " ";

            if (byte_in.Length > 0)
            {
                for (int i = 0; i < len_in; i++)
                {
                    //转换为大写十六进制字符串
                    str_out[i] = Convert.ToString(byte_in[i], 16).ToUpper();

                    //字符串显示
                    show_textbox.AppendText((str_out[i].Length == 1 ? ("0" + str_out[i]) : str_out[i]) + " ");
                }
            }
            else
            { }
        }

        /*##############################################################################################################其它程序结束*/

        //功能码03使用
        public int[] read_out_textbox()
        {
            byte index = 0;
            int j = 0;

            string[] str_in = new string[10];
            string[] str_out = new string[10];
            int[] temp_data = new int[10];

            str_in[index++] = textBox6.Text;
            str_in[index++] = textBox7.Text;
            str_in[index++] = textBox10.Text;
            str_in[index++] = textBox11.Text;

            str_in[index++] = textBox12.Text;
            str_in[index++] = textBox13.Text;
            str_in[index++] = textBox14.Text;
            str_in[index++] = textBox15.Text;

            str_in[index++] = textBox17.Text;
            str_in[index++] = textBox18.Text;

            str_out = match_data.Match_TextBox_num09_TWO(str_in, index);//数据输入非法检测

            for (int i = 0; i < index; i++)
            {
                temp_data[i] = Convert.ToInt32(str_out[j]); //只允许 0-9 其它出错
                j++;
            }

            return temp_data;
        }

        //功能码06使用 写入
        //00 01 00 00 00 06 01 03 00 01 00 01 
        public bool write_in_textbox(byte[] pin)
        {
            int get_regaddr = 0;
            byte get_regaddr_h = 0;
            byte get_regaddr_l = 0;

            int get_regdata = 0;
            byte get_regdata_h = 0;
            byte get_regdata_l = 0;

            if ((RTU_ENABLE == 0) && (ASCII_ENABLE == 1))
            {

                //获取数据地址
                get_regaddr_h = (byte)((ascii_to_hex(pin[5]) << 4) + ascii_to_hex(pin[6]));
                get_regaddr_l = (byte)((ascii_to_hex(pin[7]) << 4) + ascii_to_hex(pin[8]));
                get_regaddr = ((get_regaddr_h << 8) | get_regaddr_l);

                //获取写入数据
                get_regdata_h = (byte)((ascii_to_hex(pin[9]) << 4) + ascii_to_hex(pin[10]));
                get_regdata_l = (byte)((ascii_to_hex(pin[11]) << 4) + ascii_to_hex(pin[12]));
                get_regdata = ((get_regdata_h << 8) | get_regdata_l);
            }
            else if ((RTU_ENABLE == 1) && (ASCII_ENABLE == 0))
            {

//MBAP TCP 报文**********************************************************************

                if (MBAP_TCP_ENABLE == 1)
                {
                    get_regaddr = ((pin[8] << 8) | pin[9]);
                    get_regdata = ((pin[10] << 8) | pin[11]);
                }
                else//不需要处理
                {
                    get_regaddr = ((pin[2] << 8) | pin[3]);
                    get_regdata = ((pin[4] << 8) | pin[5]);
                }
            }
            else
            { }

            switch (get_regaddr)
            {
                case 0000: textBox6.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0001: textBox7.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0002: textBox10.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0003: textBox11.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0004: textBox12.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0005: textBox13.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0006: textBox14.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0007: textBox15.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0008: textBox17.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                case 0009: textBox18.Text = match_data.Match_TextBox_num09_ONE(get_regdata.ToString()); break;
                default: break;

            }

            return true;
        }

        //00 01 00 00 00 06 01 03 00 01 00 01 
        public void Socket_Deal_Rec_RTU(int temp_len, byte[] temp_data)
        {
            byte temp_func = 0;
            byte show_flag = 0;

            int[] reg = new int[128];
            int[] reg_copy = new int[128];

            string[] temp_str = new string[128];

            string datestring = " ";

            if (temp_len > 0)
            {
                if (temp_data[7] < 0x80)//正常功能码
                {
                    temp_func = temp_data[7];
                    switch (temp_func)
                    {
                        case 00: break;// 00 广播地址 从机不会有回应
                        case 01: break;
                        case 02: break;
                        case 03:
                            {
                                reg = read_out_textbox();
                                Serial_Modbus_RTUFunc03_Send(temp_data, reg, serialPort1, client_socket);
                                textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码03数据发送成功!");

                                break;
                            }
                        case 04: break;
                        case 05: break;
                        case 06:
                            {
                                write_in_textbox(temp_data);
                                Serial_Modbus_RTUFunc06_Send(temp_data, reg, serialPort1, client_socket);
                                textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码06数据发送成功!");

                                break;
                            }
                        case 07: break;

                        //其它功能码...
                        default: break;
                    }

                    RX_CNT++;
                    if (TX_CNT != 0)//有数据 清零按键状态改变
                    {
                        button8.Text = "可清零";
                    }

                    datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                    //显示
                    Show_Byte_To_String(temp_data, temp_str, temp_len, textBox9);//显示接收到的数据
                    textBox22.Invoke(Show_TextBox_Message, textBox22, RX_CNT.ToString() + ", " + datestring);
                }
                else//错误功能码
                {
                    show_flag = 1;//接收错误标识
                    Array.Clear(temp_data, 0, temp_len);
                }
            }
            else
            {
                ;
            }

            if (show_flag == 1)//错误标识显示
            {
                textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据接收失败，超时或无响应!");//信息显示
                show_flag = 0;
            }

        }

        public void Serial_Deal_Rec_RTU()
        {
            int temp_len = 0;

            int sum_RTU_crc = 0;
            int rec_RTU_crc = 0;

            byte temp_func = 0;
            byte show_flag = 0;

            bool temp_bool = false;

            byte[] temp_data = new byte[128];
            int[] reg = new int[128];
            int[] reg_copy = new int[128];

            string[] temp_str = new string[128];

            string datestring = " ";


            temp_len = queue.get_lenth();
            if (temp_len > 0)
            {
                queue.Delete_Queue(temp_data, temp_len);

                if (temp_data[1] < 0x80)//正常功能码
                {
                    sum_RTU_crc = cal_crc.CAL_CRC16(temp_data, temp_len - 2);
                    rec_RTU_crc = ((temp_data[temp_len - 2] << 8) + temp_data[temp_len - 1]);

                    if (sum_RTU_crc == rec_RTU_crc)
                    {
                        temp_func = temp_data[1];
                        switch (temp_func)
                        { 
                            case 00: break;// 00 广播地址 从机不会有回应
                            case 01: break;
                            case 02: break;
                            case 03:
                                {
                                    reg = read_out_textbox();
                                    Serial_Modbus_RTUFunc03_Send(temp_data, reg, serialPort1, client_socket);
                                    textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码03数据发送成功!");
                                    
                                    break;
                                } 
                            case 04: break;
                            case 05: break;
                            case 06:
                                {
                                    write_in_textbox(temp_data);
                                    Serial_Modbus_RTUFunc06_Send(temp_data, reg, serialPort1, client_socket);
                                    textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码06数据发送成功!");

                                    break;
                                }
                            case 07: break;

                            //其它功能码...
                            default:break;
                        }

                        RX_CNT++;
                        if (TX_CNT != 0)//有数据 清零按键状态改变
                        {
                            button8.Text = "可清零";
                        }

                        datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                        //显示
                        Show_Byte_To_String(temp_data, temp_str, temp_len, textBox9);//显示接收到的数据
                        textBox22.Invoke(Show_TextBox_Message, textBox22, RX_CNT.ToString() + ", " + datestring);
                    }
                    else//CRC校验错误
                    {
                        show_flag = 1;//接收错误标识
                        Array.Clear(temp_data, 0, temp_len);
                    }
                }
                 else//错误功能码
                {
                    show_flag = 1;//接收错误标识
                    Array.Clear(temp_data, 0, temp_len);
                }
            }
            else
            {
                ;
            }

            if (show_flag == 1)//错误标识显示
            {
                textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据接收失败，超时或无响应!");//信息显示
                show_flag = 0;
            }

        }

        public bool Deal_RecFrame_Data_ONE()
        {
            int temp_len = 0;
            byte temp_data = 0;
            byte[] get_data = new byte[128];

            //进来先清空之前的缓冲区
            //避免数组越界
            Frame_List.Clear_Fream();

            temp_len = queue.get_lenth();

            if (temp_len > 0)
            {
                queue.Delete_Queue(get_data, temp_len);

                for (int i = 0; i < temp_len; i++)
                {
                    temp_data = get_data[i];//获取一个数据

                    if (Frame_List.frame_header_flag < Frame_List.head[0])
                    {
                        Frame_List.Find_Frame_Header(temp_data);
                    }
                    else
                    {
                        //容易出错
                        Frame_List.frame_rbuff[Frame_List.frame_len++] = temp_data;

                        if (Frame_List.Find_Frame_tail() == 0)
                        {
                            if ((Frame_List.min_len == 0) || (Frame_List.min_len > 0) && (Frame_List.frame_len > Frame_List.min_len))
                            {
                                return true;
                            }
                            else
                            {
                                Frame_List.Clear_Fream();
                            }
                        }
                        if (Frame_List.frame_len > Frame_List.frame_size)
                        {
                            Frame_List.Clear_Fream();
                        }
                    }
                }
            }
            else
            {
                ;
            }
            return false;
        }

        public void Serial_Deal_RecFrame_ASCII()
        {
            byte sum_crc = 0;
            byte rec_crc = 0;
            byte slave_addr = 0;
            byte func_code = 0;
            int temp_len = 0;
            byte show_flag = 0;

            byte temp = 0;
            bool temp_bool = false;

            byte[] temp_data = new byte[128];
            int[] reg = new int[128];

            string[] temp_str = new string[128];

            string datestring = " ";

            if (Deal_RecFrame_Data_ONE() == true)
            {
                Buffer.BlockCopy(Frame_List.frame_rbuff, 0, temp_data, 0, Frame_List.frame_len);//数据拷贝

                temp_len = Frame_List.frame_len;

                //CRC校验
                //一个数据分两次传
                //去掉 :

                sum_crc = cal_crc.CAL_LQR(temp_data, temp_len - 5);
                rec_crc = (byte)((ascii_to_hex(temp_data[temp_len - 4]) << 4) + ascii_to_hex(temp_data[temp_len - 3]));

                if (sum_crc == rec_crc)//校验正确
                {
                    slave_addr = (byte)((ascii_to_hex(temp_data[1]) << 4) + ascii_to_hex(temp_data[2]));
                    temp = Convert.ToByte(textBox2.Text);

                    if (slave_addr == temp)//地址正确
                    {
                        func_code = (byte)((ascii_to_hex(temp_data[3]) << 4) + ascii_to_hex(temp_data[4]));
                        switch (func_code)//功能码
                        {
                            case 0: break;
                            case 1: break;
                            case 2: break;
                            case 3: 
                                {
                                    reg = read_out_textbox();
                                    Serial_Modbus_ASCIIFunc03_Send(temp_data, reg, serialPort1);
                                    textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码03数据发送成功!");
                                    break;
                                }
                            case 4: break;
                            case 5: break;
                            case 6:
                                {
                                    write_in_textbox(temp_data);                                   
                                    Serial_Modbus_ASCIIFunc06_Send(temp_data, reg, serialPort1);
                                    textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus功能码06数据发送成功!");

                                    break;
                                }
                            case 7: break;
                            case 8: break;
                            case 9: break;
                            default: break;

                            //添加更多功能码 实现函数
                                
                        }

                        RX_CNT++;
                        if (RX_CNT != 0)//有数据 清零按键状态改变
                        {
                            button8.Text = "可清零";
                        }

                        datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

                        //显示
                        Show_Byte_To_String(temp_data, temp_str, temp_len, textBox9);//显示接收到的数据
                        textBox22.Invoke(Show_TextBox_Message, textBox22, RX_CNT.ToString() + ", " + datestring);
                    }
                    else if (slave_addr == 0)//广播地址 不用回应
                    {
                        textBox9.Text = " ";
                    }
                }
                else //校验出错
                {
                    textBox9.Text = " ";
                    Array.Clear(temp_data, 0, temp_len);//数据丢弃
                    show_flag = 1;//接收错误标识
                }

                Frame_List.Clear_Fream();//清除帧缓冲区
            }

            if (show_flag == 1)//错误标识显示
            {
                textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据接收失败，超时或无响应!");//信息显示
                show_flag = 0;
            }

        }

        /*##############################################################################################################MODBUS程序开始*/

        public byte hex_to_ascii(byte bHex)
        {
            if ((bHex >= 0) && (bHex <= 9)) bHex += 0x30;
            else if ((bHex >= 10) && (bHex <= 15)) bHex += 0x37;
            else bHex = 0xff;

            return bHex;
        }

        public byte ascii_to_hex(byte bChar)
        {
            if ((bChar >= 0x30) && (bChar <= 0x39)) bChar -= 0x30;
            else if ((bChar >= 0x41) && (bChar <= 0x46)) bChar -= 0x37;
            else if ((bChar >= 0x61) && (bChar <= 0x66)) bChar -= 0x57;
            else bChar = 0xff;

            return bChar;
        }

        //功能码3 获取寄存器数值
        // 00 01 00 00 00 06 01 03 00 01 00 01 
        void Serial_Modbus_RTUFunc03_Send(byte[] pin, int[] reg, SerialPort serialport_send, Socket socket_send) 
        {
            int get_regaddr = 0;
            int get_reglen = 0;

            int index = 0;
            int i = 0;
            int sum_crc = 0;
            byte temp = 0;

            string str = " ";
            string datestring = " ";
  
            //数据暂存
            byte[] send_table = new byte[128];
            string[] str_table = new string[128];

//MBAP TCP 报文**********************************************************************

            if (MBAP_TCP_ENABLE == 1)
            {
                int mbap_cnt = 0;
                int mbap_modbus = 0;
                int mbap_len = 0;

                get_regaddr = ((pin[8] << 8) | pin[9]);
                get_reglen = ((pin[10] << 8) | pin[11]);

                mbap_cnt = ((pin[0] << 8) | pin[1]);
                mbap_modbus = ((pin[2] << 8) | pin[3]);
                mbap_len = ((get_reglen*2) + 3);

                //添加发送信息
                send_table[index++] = (byte)(mbap_cnt>>8);
                send_table[index++] = (byte)(mbap_cnt%256);

                send_table[index++] = (byte)(mbap_modbus>>8);
                send_table[index++] = (byte)(mbap_modbus%256);

                send_table[index++] = (byte)((mbap_len) >> 8);
                send_table[index++] = (byte)((mbap_len) % 256);

            }
            else//不需要处理
            {
                get_regaddr = ((pin[2] << 8) | pin[3]);
                get_reglen = ((pin[4] << 8) | pin[5]);
            }

            //返回地址 功能码 
            str = match_data.Match_TextBox_num09_ONE(textBox2.Text);
            temp = Convert.ToByte(str);
            send_table[index++] = temp;
            send_table[index++] = 0X03;
  
            send_table[index++] = (byte)((get_reglen*2)%256);//16位 分高低8位传输 *2
  
            //装入数据
            for(i=0;i<get_reglen;i++)
            {
                send_table[index++] = (byte)(reg[get_regaddr+i]>>8);
                send_table[index++] = (byte)(reg[get_regaddr+i]%256);
            }
 
//MBAP TCP 报文**********************************************************************

            if (MBAP_TCP_ENABLE == 0)
            {
                //CRC校验
                sum_crc = cal_crc.CAL_CRC16(send_table, index);

                send_table[index++] = (byte)(sum_crc >> 8);
                send_table[index++] = (byte)(sum_crc % 256);
            }
            else
            { }

            if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))//UART
            {
                if ((serialport_send.IsOpen) && (index > 0))
                {
                    serialport_send.Write(send_table, 0, index);//发送
                }
                else//error
                { }
            }
            else if ((UART_ENABLE == 0) && (TCP_ENABLE == 1))//TCP/IP
            {
                if ((socket_send.Connected) && (index > 0))
                {
                    socket_send.Send(send_table, 0, index, SocketFlags.None);//发送
                }
                else//error
                { }
            }

            //发送
            

            TX_CNT++;
            if (TX_CNT != 0)//有数据 清零按键状态改变
            {
                button9.Text = "可清零";
            }

            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

            //显示
            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据发送成功!");
            textBox3.Invoke(Show_TextBox_Message, textBox3, TX_CNT.ToString() + ", " + datestring);
            Show_Byte_To_String(send_table, str_table, index, textBox8);//显示已发送的数据
    
        }

        //功能码6 写入寄存器数值
        //00 01 00 00 00 06 01 03 00 01 00 01 
        void Serial_Modbus_RTUFunc06_Send(byte[] pin, int[] reg, SerialPort serialport_send, Socket socket_send) 
        {
            int get_regaddr = 0;
            int get_regdata = 0;

            int index = 0;
            int sum_crc = 0;
            byte temp = 0;

            string str = " ";
            string datestring = " ";

            //数据暂存
            byte[] send_table = new byte[128];
            string[] str_table = new string[128];

//MBAP TCP 报文**********************************************************************

            if (MBAP_TCP_ENABLE == 1)
            {
                int mbap_cnt = 0;
                int mbap_modbus = 0;
                int mbap_len = 0;

                get_regaddr = ((pin[8] << 8) | pin[9]);
                get_regdata = ((pin[10] << 8) | pin[11]);

                mbap_cnt = ((pin[0] << 8) | pin[1]);
                mbap_modbus = ((pin[2] << 8) | pin[3]);
                mbap_len = ((pin[4] << 8) | pin[5]);

                //添加发送信息
                send_table[index++] = (byte)(mbap_cnt >> 8);
                send_table[index++] = (byte)(mbap_cnt % 256);

                send_table[index++] = (byte)(mbap_modbus >> 8);
                send_table[index++] = (byte)(mbap_modbus % 256);

                send_table[index++] = (byte)((mbap_len) >> 8);
                send_table[index++] = (byte)((mbap_len) % 256);

            }
            else//不需要处理
            {
                get_regaddr = ((pin[2] << 8) | pin[3]);
                get_regdata = ((pin[4] << 8) | pin[5]);
            }

            //数据存入
            reg[get_regaddr] = get_regdata;

            //返回地址 功能码 
            str = match_data.Match_TextBox_num09_ONE(textBox2.Text);
            temp = Convert.ToByte(str);
            send_table[index++] = temp;
            send_table[index++] = 0X06;
  
            //返回寄存器地址
            send_table[index++] = (byte)((get_regaddr&0XFFFF)>>8);
            send_table[index++] = (byte)(get_regaddr&0XFF);
  
            //返回写入数据
            send_table[index++] = (byte)((get_regdata&0XFFFF)>>8);
            send_table[index++] = (byte)(get_regdata&0XFF);

//MBAP TCP 报文**********************************************************************

            if (MBAP_TCP_ENABLE == 0)
            {
                //CRC校验
                sum_crc = cal_crc.CAL_CRC16(send_table, index);

                send_table[index++] = (byte)(sum_crc >> 8);
                send_table[index++] = (byte)(sum_crc % 256);
            }
            else
            { }

            if ((UART_ENABLE == 1) && (TCP_ENABLE == 0))//UART
            {
                if ((serialport_send.IsOpen) && (index > 0))
                {
                    serialport_send.Write(send_table, 0, index);//发送
                }
                else//error
                { }
            }
            else if ((UART_ENABLE == 0) && (TCP_ENABLE == 1))//TCP/IP
            {
                if ((socket_send.Connected) && (index > 0))
                {
                    socket_send.Send(send_table, 0, index, SocketFlags.None);//发送
                }
                else//error
                { }
            }

            TX_CNT++;
            if (TX_CNT != 0)//有数据 清零按键状态改变
            {
                button9.Text = "可清零";
            }

            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

            //显示
            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据发送成功!");
            textBox3.Invoke(Show_TextBox_Message, textBox3, TX_CNT.ToString() + ", " + datestring);
            Show_Byte_To_String(send_table, str_table, index, textBox8);//显示已发送的数据
    
        }

        //功能码3 获取寄存器数值
        public void Serial_Modbus_ASCIIFunc03_Send(byte[] pin, int[] reg, SerialPort serialport_send) 
        {
            int get_regaddr = 0;
            byte get_regaddr_h = 0;
            byte get_regaddr_l = 0;
  
            int get_reglen = 0; 
            byte get_reglen_h = 0;
            byte get_reglen_l = 0;

            int index = 0;
            int i = 0;
            byte sum_crc = 0;
            byte temp = 0;

            string str = " ";
            string datestring = " ";
  
            //数据暂存
            byte[] send_table = new byte[128];
            string[] str_table = new string[128];
  
            get_regaddr_h = (byte)((ascii_to_hex(pin[5])<<4) + ascii_to_hex(pin[6]));
            get_regaddr_l = (byte)((ascii_to_hex(pin[7])<<4) + ascii_to_hex(pin[8]));
            get_regaddr = ((get_regaddr_h<<8)|get_regaddr_l);
  
            get_reglen_h = (byte)((ascii_to_hex(pin[9])<<4) + ascii_to_hex(pin[10]));
            get_reglen_l = (byte)((ascii_to_hex(pin[11])<<4) + ascii_to_hex(pin[12]));
            get_reglen = ((get_reglen_h<<8)|get_reglen_l);
  
            // 开始标志
            send_table[index++] = (byte)':';
  
            // 返回地址 
            str = match_data.Match_TextBox_num09_ONE(textBox2.Text);
            temp = Convert.ToByte(str);
            send_table[index++] = hex_to_ascii((byte)((temp & 0xFF) >> 4));
            send_table[index++] = hex_to_ascii((byte)((temp & 0xFF) % 16));

            // 功能码 
            send_table[index++] = hex_to_ascii((0X03 & 0xFF) >> 4);
            send_table[index++] = hex_to_ascii((0X03 & 0xFF) % 16);
  
            //数据长度
            send_table[index++] = hex_to_ascii((byte)(((get_reglen*2) & 0xFF) >> 4));
            send_table[index++] = hex_to_ascii((byte)(((get_reglen*2) & 0xFF) % 16));
  
            //装入数据
            for(i=0;i<get_reglen;i++)
            {
                send_table[index++] = hex_to_ascii((byte)((((reg[get_regaddr+i] & 0xFFFF) >> 8) >> 4)));
                send_table[index++] = hex_to_ascii((byte)((((reg[get_regaddr+i] & 0xFFFF) >> 8) % 16)));
                send_table[index++] = hex_to_ascii((byte)(((reg[get_regaddr+i] & 0xFF) >> 4)));
                send_table[index++] = hex_to_ascii((byte)(((reg[get_regaddr+i] & 0xFF) % 16)));
            }

            //CRC校验
            sum_crc = cal_crc.CAL_LQR(send_table, index - 1);
            send_table[index++] = hex_to_ascii((byte)((sum_crc & 0xFF) >> 4));
            send_table[index++] = hex_to_ascii((byte)((sum_crc & 0xFF) % 16));

            // 结束标志
            send_table[index++] =(byte) '\r';
            send_table[index++] =(byte) '\n';

            //发送
            serialport_send.Write(send_table,0, index);

            TX_CNT++;
            if (TX_CNT != 0)//有数据 清零按键状态改变
            {
                button9.Text = "可清零";
            }

            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

            //显示
            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据发送成功!");
            textBox3.Invoke(Show_TextBox_Message, textBox3, TX_CNT.ToString() + ", " + datestring);
            Show_Byte_To_String(send_table, str_table, index, textBox8);//显示已发送的数据
    
        }

        //功能码6 写入寄存器数值
        public void Serial_Modbus_ASCIIFunc06_Send(byte[] pin,int[] reg,SerialPort serialport_send) 
        {
            int get_regaddr = 0;
            byte get_regaddr_h = 0;
            byte get_regaddr_l = 0;
  
            int get_regdata = 0; 
            byte get_regdata_h = 0;
            byte get_regdata_l = 0;

            int index = 0;
            byte sum_crc = 0;
            byte temp = 0;

            string str = " ";
            string datestring = " ";

            //数据暂存
            byte[] send_table = new byte[128];
            string[] str_table = new string[128];

            get_regaddr_h = (byte)((ascii_to_hex(pin[5]) << 4) + ascii_to_hex(pin[6]));
            get_regaddr_l = (byte)((ascii_to_hex(pin[7]) << 4) + ascii_to_hex(pin[8]));
            get_regaddr = ((get_regaddr_h << 8) | get_regaddr_l);

            get_regdata_h = (byte)((ascii_to_hex(pin[9]) << 4) + ascii_to_hex(pin[10]));
            get_regdata_l = (byte)((ascii_to_hex(pin[11]) << 4) + ascii_to_hex(pin[12]));
            get_regdata = ((get_regdata_h << 8) | get_regdata_l);

            //数据存入
            reg[get_regaddr] = get_regdata;
  
            // 开始标志
            send_table[index++] = (byte)':';
  
            // 返回地址 
            str = match_data.Match_TextBox_num09_ONE(textBox2.Text);
            temp = Convert.ToByte(str);
            send_table[index++] = hex_to_ascii((byte)((temp & 0xFF) >> 4));
            send_table[index++] = hex_to_ascii((byte)((temp & 0xFF) % 16));
  
            // 功能码 
            send_table[index++] = hex_to_ascii((0X06 & 0xFF) >> 4);
            send_table[index++] = hex_to_ascii((0X06 & 0xFF) % 16);

            //数据地址
            send_table[index++] = hex_to_ascii((byte)((((get_regaddr & 0xFFFF) >> 8) >> 4)));
            send_table[index++] = hex_to_ascii((byte)((((get_regaddr & 0xFFFF) >> 8) % 16)));
            send_table[index++] = hex_to_ascii((byte)(((get_regaddr & 0xFF) >> 4)));
            send_table[index++] = hex_to_ascii((byte)(((get_regaddr & 0xFF) % 16)));
  
            //写入数据 
            send_table[index++] = hex_to_ascii((byte)((((get_regdata & 0xFFFF) >> 8) >> 4)));
            send_table[index++] = hex_to_ascii((byte)((((get_regdata & 0xFFFF) >> 8) % 16)));
            send_table[index++] = hex_to_ascii((byte)(((get_regdata & 0xFF) >> 4)));
            send_table[index++] = hex_to_ascii((byte)(((get_regdata & 0xFF) % 16)));
  
            //CRC校验
            sum_crc = cal_crc.CAL_LQR(send_table, index - 1);
            send_table[index++] = hex_to_ascii((byte)((sum_crc & 0xFF) >> 4));
            send_table[index++] = hex_to_ascii((byte)((sum_crc & 0xFF) % 16));
  
            // 结束标志
            send_table[index++] = (byte)'\r';
            send_table[index++] = (byte)'\n';

            //发送
            serialport_send.Write(send_table, 0, index);

            TX_CNT++;
            if (TX_CNT != 0)//有数据 清零按键状态改变
            {
                button9.Text = "可清零";
            }

            datestring = GetTime(GetTimeStamp()).ToString("yyyy-MM-dd HH:mm:ss");//获取时间

            //显示
            textBox23.Invoke(Show_TextBox_Message, textBox23, "Modbus数据发送成功!");
            textBox3.Invoke(Show_TextBox_Message, textBox3, TX_CNT.ToString() + ", " + datestring);
            Show_Byte_To_String(send_table, str_table, index, textBox8);//显示已发送的数据
 
        }

        /*##############################################################################################################MODBUS程序结束*/


        /*##############################################################################################################自己写的类开始*/

        /*************************************************************************************************************LOOP_QUEUE*/
        public class loop_queue_list<T>
        {
            public int LOOP_QUEUE_SIZE_MAX;     //数组容量最大值
            public int head_pointer;            //头指针
            public int tail_pointer;            //尾指针
            public T[] array;                   //数组

            //构造函数
            public loop_queue_list(int size)
            {
                this.LOOP_QUEUE_SIZE_MAX = size;
                this.head_pointer = 0;
                this.tail_pointer = 0;
                this.array = new T[size];
            }

            public bool Insert_Queue(T value)
            {
                if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                {
                    return false;
                }
                else
                {
                    array[tail_pointer] = value;
                    tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return true;
                }
            }

            public void Insert_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if ((tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX == head_pointer)//满了
                    {
                        return;
                    }
                    else
                    {
                        array[tail_pointer] = pdat[i];
                        tail_pointer = (tail_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public T Delete_Queue()
            {
                T value = default(T);

                if (tail_pointer == head_pointer)//空了
                {
                    return value;
                }
                else
                {
                    value = array[head_pointer];
                    head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    return value;
                }
            }

            public void Delete_Queue(T[] pdat, int len)
            {
                for (int i = 0; i < len; i++)
                {
                    if (tail_pointer == head_pointer)//空了
                    {
                        return;
                    }
                    else
                    {
                        pdat[i] = array[head_pointer];
                        head_pointer = (head_pointer + 1) % LOOP_QUEUE_SIZE_MAX;
                    }
                }
            }

            public int get_lenth()
            {
                return ((tail_pointer + LOOP_QUEUE_SIZE_MAX - head_pointer) % LOOP_QUEUE_SIZE_MAX);
            }
        }

        /**********************************************************************************************结束*************LOOP_QUEUE */

        /***********************************************************************************************************************MATH*/

        public class Rec_Frame_List
        {
            public byte[] head;                           //帧头
            public byte[] tail;                           //帧尾
            public byte min_len;                          //最小帧长度

            public byte frame_header_flag;                //帧头标志
            public byte[] frame_rbuff;                    //帧缓冲区
            public int frame_size;                        //帧缓冲区大小
            public int frame_len;                         //帧缓冲区长度

            //构造函数
            public Rec_Frame_List(int size)
            {
                this.head = new byte[3] { 0x01, 0x3A, 0X00 };//可替换帧头帧尾 
                this.tail = new byte[3] { 0x02, 0x0D, 0X0A };
                this.min_len = 7;
                this.frame_header_flag = 255;
                this.frame_len = 0;
                this.frame_rbuff = new byte[size];
                this.frame_size = size;
            }

            public void Clear_Fream()
            {
                frame_header_flag = 255;
                frame_len = 0;
                Array.Clear(frame_rbuff, 0, frame_size);
            }

            public void Find_Frame_Header(byte data_in)
            {
                if (head[0] <= 2)
                {
                    if (data_in == (frame_rbuff[frame_header_flag + 1]))
                    {
                        frame_rbuff[frame_len++] = data_in;
                        frame_header_flag++;
                        return;
                    }
                }
                else
                {
                }
                Clear_Fream();
            }

            public byte Find_Frame_tail()
            {
                if (tail[0] == 1)
                {
                    if (frame_rbuff[frame_len - 1] == tail[1])
                    {
                        return 0;
                    }
                }
                else if (tail[0] == 2)
                {
                    if (frame_len > 2)
                    {
                        if ((frame_rbuff[frame_len - 2] == tail[1]) && (frame_rbuff[frame_len - 1] == tail[2]))
                        {
                            return 0;
                        }
                    }
                }
                else
                {
                    return 1;
                }
                return 2;
            }

        }

        //数据转义
        private int Div_Data_Escape(byte[] pin, byte[] pout, int len)
        {
            int i = 0;
            int temp_len = 0;

            for (i = 0; i < len; i++)
            {
                if ((i == 0) || (i == len - 1))
                {
                    pout[temp_len++] = pin[i];
                }
                else
                {
                    if ((pin[i] == 0x7E) || (pin[i] == 0x7F))//可替换帧头帧尾 插入数据
                    {
                        pout[temp_len++] = 0x33;
                        pout[temp_len++] = (byte)(pin[i] - (byte)0x11);
                    }
                    else
                    {
                        pout[temp_len++] = pin[i];
                    }
                }
            }
            return temp_len;
        }

        //数据反转义
        private int Div_Data_UnEscape(byte[] pin, byte[] pout, int len)
        {
            int i = 0;
            int temp_len = 0;

            for (i = 0; i < len; i++)
            {
                if (pin[i] == 0x33)//可替换帧头帧尾 插入数据
                {
                    i = i + 1;
                    pout[temp_len++] = ((byte)((pin[i]) + 0x11));
                }
                else
                {
                    pout[temp_len++] = pin[i];
                }
            }
            return temp_len;
        }

        /*********************************************************************************************************结束*********MATH*/

        /***********************************************************************************************************************CRC*/

        public class cal_check_list
        {
            //构造函数
            public cal_check_list()
            {

            }

            /* CRC 高位字节值表 */
            byte[] auchCRCHi = new byte[256]{
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40, 0x00, 0xC1, 0x81, 0x40,
                0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0, 0x80, 0x41, 0x00, 0xC1,
                0x81, 0x40, 0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41,
                0x00, 0xC1, 0x81, 0x40, 0x01, 0xC0, 0x80, 0x41, 0x01, 0xC0,
                0x80, 0x41, 0x00, 0xC1, 0x81, 0x40
        };

            /* CRC低位字节值表*/
            byte[] auchCRCLo = new byte[256]{
                0x00, 0xC0, 0xC1, 0x01, 0xC3, 0x03, 0x02, 0xC2, 0xC6, 0x06,
                0x07, 0xC7, 0x05, 0xC5, 0xC4, 0x04, 0xCC, 0x0C, 0x0D, 0xCD,
                0x0F, 0xCF, 0xCE, 0x0E, 0x0A, 0xCA, 0xCB, 0x0B, 0xC9, 0x09,
                0x08, 0xC8, 0xD8, 0x18, 0x19, 0xD9, 0x1B, 0xDB, 0xDA, 0x1A,
                0x1E, 0xDE, 0xDF, 0x1F, 0xDD, 0x1D, 0x1C, 0xDC, 0x14, 0xD4,
                0xD5, 0x15, 0xD7, 0x17, 0x16, 0xD6, 0xD2, 0x12, 0x13, 0xD3,
                0x11, 0xD1, 0xD0, 0x10, 0xF0, 0x30, 0x31, 0xF1, 0x33, 0xF3,
                0xF2, 0x32, 0x36, 0xF6, 0xF7, 0x37, 0xF5, 0x35, 0x34, 0xF4,
                0x3C, 0xFC, 0xFD, 0x3D, 0xFF, 0x3F, 0x3E, 0xFE, 0xFA, 0x3A,
                0x3B, 0xFB, 0x39, 0xF9, 0xF8, 0x38, 0x28, 0xE8, 0xE9, 0x29,
                0xEB, 0x2B, 0x2A, 0xEA, 0xEE, 0x2E, 0x2F, 0xEF, 0x2D, 0xED,
                0xEC, 0x2C, 0xE4, 0x24, 0x25, 0xE5, 0x27, 0xE7, 0xE6, 0x26,
                0x22, 0xE2, 0xE3, 0x23, 0xE1, 0x21, 0x20, 0xE0, 0xA0, 0x60,
                0x61, 0xA1, 0x63, 0xA3, 0xA2, 0x62, 0x66, 0xA6, 0xA7, 0x67,
                0xA5, 0x65, 0x64, 0xA4, 0x6C, 0xAC, 0xAD, 0x6D, 0xAF, 0x6F,
                0x6E, 0xAE, 0xAA, 0x6A, 0x6B, 0xAB, 0x69, 0xA9, 0xA8, 0x68,
                0x78, 0xB8, 0xB9, 0x79, 0xBB, 0x7B, 0x7A, 0xBA, 0xBE, 0x7E,
                0x7F, 0xBF, 0x7D, 0xBD, 0xBC, 0x7C, 0xB4, 0x74, 0x75, 0xB5,
                0x77, 0xB7, 0xB6, 0x76, 0x72, 0xB2, 0xB3, 0x73, 0xB1, 0x71,
                0x70, 0xB0, 0x50, 0x90, 0x91, 0x51, 0x93, 0x53, 0x52, 0x92,
                0x96, 0x56, 0x57, 0x97, 0x55, 0x95, 0x94, 0x54, 0x9C, 0x5C,
                0x5D, 0x9D, 0x5F, 0x9F, 0x9E, 0x5E, 0x5A, 0x9A, 0x9B, 0x5B,
                0x99, 0x59, 0x58, 0x98, 0x88, 0x48, 0x49, 0x89, 0x4B, 0x8B,
                0x8A, 0x4A, 0x4E, 0x8E, 0x8F, 0x4F, 0x8D, 0x4D, 0x4C, 0x8C,
                0x44, 0x84, 0x85, 0x45, 0x87, 0x47, 0x46, 0x86, 0x82, 0x42,
                0x43, 0x83, 0x41, 0x81, 0x80, 0x40
        };
            //CRC16
            public int CAL_CRC16(byte[] puchMsg, int usDataLen)
            {
                byte uchCRCHi = 0xFF;                           // 高CRC字节初始化
                byte uchCRCLo = 0xFF;                           // 低CRC 字节初始化
                long uIndex; 		                             // CRC循环中的索引

                for (long i = 0; i < usDataLen; i++)
                {
                    uIndex = uchCRCHi ^ puchMsg[i]; 	    // 计算CRC
                    uchCRCHi = (byte)(uchCRCLo ^ auchCRCHi[uIndex]);
                    uchCRCLo = (byte)auchCRCLo[uIndex];
                }

                return (uchCRCHi << 8 | uchCRCLo);
            }

            //LQR
            public byte CAL_LQR(byte[] paddr, int cnt)
            {
                int i = 0;
                byte sum = 0;

                for (i = 1; i < cnt; i++)
                {
                    sum += paddr[i];
                }

                sum = (byte)((~sum) + 1);

                return (sum);
            }

        }

        //异或校验
        private byte CAL_XOR(byte[] pdat, int len)
        {
            int i = 0;
            byte sum = 0;

            for (i = 0; i < len; i++)
            {
                sum ^= pdat[i];
            }
            return (byte)sum;
        }

        /*************************************************************************************************************结束*******CRC*/

        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################开始

        public class match_textbox_list
        {
            //构造函数
            public match_textbox_list()
            {

            }

            string pattern = @"^[0-9]*$";

            public string Match_TextBox_num09_ONE(string str_in)
            {
                string str = " ";
                string str_out = " ";

                str = str_in.Trim();//自动去空

                if (str.Contains(" "))
                {
                    str = str.Replace(" ", "");
                }

                Match m = Regex.Match(str, pattern);//匹配正则表达式 

                if (!m.Success)//输入的不是数字
                {
                    MessageBox.Show("输入数据非法！0-9之间的数据允许输入", "数据输入非法提示");
                }
                else //输入的是数字
                {
                    str_out = str;
                }

                return str_out;
            }

            public string[] Match_TextBox_num09_TWO(string[] str_in, int cnt)
            {
                string[] str = new string[128];
                string[] str_out = new string[128];

                for (int i = 0; i < cnt; i++)
                {
                    str[i] = str_in[i].Trim();      //自动去空

                    if (str[i].Contains(" "))
                    {
                        str[i] = str[i].Replace(" ", "");
                    }

                    Match m = Regex.Match(str[i], pattern);//匹配正则表达式 

                    if (!m.Success)//输入的不是数字
                    {
                        MessageBox.Show("要修改数据非法！请输入0-9之间的数据", "数据输入非法提示");
                    }
                    else //输入的是数字
                    {
                        str_out[i] = str[i];
                    }
                }
                return str_out;
            }
        }

        //textbox控件输入 正则表达式 自动去空等非法检测################################################################################结束

        /*##############################################################################################################自己写的类结束*/

        /*无用操作区域#################################################################################开始*/

        private void textBox16_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton6_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void textBox18_TextChanged(object sender, EventArgs e)
        {

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            
        }

        /*无用操作区域#################################################################################结束*/
    }
}
